module.exports = {
  dbUri: 'your_mongo_db_connection_string_here',
};