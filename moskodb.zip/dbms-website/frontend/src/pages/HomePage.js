import React from 'react';

function HomePage() {
  return (
    <div>
      <h1>Welcome to DBMS</h1>
    </div>
  );
}

export default HomePage;